<?php $__env->startSection('page', 'Detalles del usuario'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="form-row">
		<div class="col-sm-6 mb-3">
			<label for="PlanName">Nombre del plan</label>
			<input type="text" name="plan_name" class="form-control is-valid" id="PlanName" value="<?php echo e($plan->plan_name); ?>" disabled>
			<div class="invalid-feedback">¡Debes agregar un nombre al plan!</div>
		</div>

		<div class="col-sm-6 mb-3">
			<label for="details">Detalles del plan</label>
			<textarea name="plan_description" class="form-control is-valid" id="details" rows="7" placeholder="<?php echo e($plan->plan_description); ?>" disabled></textarea>
			<div class="invalid-feedback">¡Debes agregar los detalles del plan!</div>
		</div>

		<div class="col-sm-6 mb-3">
			<label for="PlanPrice">Precio del plan</label>
			<input type="text" name="plan_price" class="form-control is-valid" id="PlanPrice" value="<?php echo e($plan->plan_price); ?>" disabled>
			<div class="invalid-feedback">¡Debes agregar un precio al plan!</div>
		</div>

		<div class="col-sm-6 mb-3">
			<label for="PlanType">Tipo de plan</label>
			<input type="text" name="plan_type" class="form-control is-valid" id="PlanType" value="<?php echo e($plan->plan_type); ?>" disabled>
			<div class="invalid-feedback">¡Debes agregar un tipo de plan!</div>
		</div>

		<hr>

		<div class="col-sm-6 mb-3">
			<label for="ModalName">Nombre del modal</label>
			<input type="text" name="name" class="form-control is-valid" id="ModalName" value="<?php echo e($plan->name); ?>" disabled>
			<div class="invalid-feedback">¡Debes agregar un nombre al modal!</div>
		</div>

		<div class="col-sm-6 mb-3">
			<label for="ModalDescription">Descripción del plan</label>
			<input type="text" name="description" class="form-control is-valid" id="ModalDescription" value="<?php echo e($plan->description); ?>" disabled>
			<div class="invalid-feedback">¡Debes agregar una descripción al plan!</div>
		</div>

		<div class="col-sm-6 mb-3">
			<label for="btnText">Texto del botón</label>
			<input type="text" name="btn_label" class="form-control is-valid" id="btnText" value="<?php echo e($plan->btn_label); ?>" disabled>
			<div class="invalid-feedback">¡Debes agregar un texto al botón!</div>
		</div>

		<div class="col-sm-6 mb-3">
			<label for="btnAmount">Monto a cobrar</label>
			<input type="text" name="amount" class="form-control is-valid" id="btnAmount" value="<?php echo e($plan->amount); ?>" disabled>
			<div class="invalid-feedback">¡Debes agregar un monto!</div>
		</div>

	<a class="btn btn-outline-success" href="<?php echo e(route('plan.index')); ?>"><i class="fas fa-arrow-circle-left"></i> Volver</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>