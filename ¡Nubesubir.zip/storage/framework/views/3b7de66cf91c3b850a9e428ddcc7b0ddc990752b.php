<?php $__env->startSection('page', 'Mis suscripciones'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-sm-12 table-responsive">
			<table class="table table-hover">
				<thead>
					<tr>
						<th scope="col">Nombre</th>
						<th scope="col">ID Stripe</th>
						<th scope="col">Creada</th>
						<th scope="col">Finalizará</th>
						<th scope="col">Acciones</th>
					</tr>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $subscriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subscription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>

							<th scope="row"><?php echo e($subscription->name); ?></th>
							<th scope="row"><?php echo e($subscription->stripe_id); ?></th>
							<th scope="row"><?php echo e($subscription->created_at->DiffForHumans()); ?></th>

							<th scope="row">
								<?php echo e($subscription->ends_at ? $subscription->ends_at->DiffForHumans() : 'La suscripción está activa'); ?>

							</th>
							
							<th scope="row">
								<?php if($subscription->ends_at): ?>
									<form action="<?php echo e(route('subscriptions.resume')); ?>" method="POST">
										<?php echo csrf_field(); ?>
										<input type="hidden" name="plan_name" value="<?php echo e($subscription->name); ?>">
										<button class="btn btn-success">Suscribirme</button>
									</form>
								<?php else: ?>
									<form action="<?php echo e(route('subscriptions.cancel')); ?>" method="POST">
										<?php echo csrf_field(); ?>
										<input type="hidden" name="plan_name" value="<?php echo e($subscription->name); ?>">
										<button class="btn btn-danger">Cancelar</button>
									</form>
								<?php endif; ?>
							
							</th>
						</tr>
					</tbody>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="container mb-5">
					      <div class="alert alert-warning" role="alert">
					         <span class="closebtn" onclick="this.parentElement.style.display='none';">x</span>
					         <strong>¡Atención!</strong> No se encontraron suscripciones
					      </div>
					   </div>
					<?php endif; ?>
				</table>
			</div>
	</div>
</div>

<!-- Modal -->
	<?php echo $__env->make('admin.partials.modals.files', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo $__env->make('admin.partials.js.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>