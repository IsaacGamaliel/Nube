<?php $__env->startSection('page', 'Todos los planes'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container">
	<div class="row">

		<div class="col-sm-12 mb-5">
			<a class="btn btn-outline-success" href="<?php echo e(route('plan.create')); ?>"><i class="fas fa-plus-circle"></i> Agregar un plan</a>
		</div>

		<div class="col-sm-12 table-responsive">
			<table class="table table-hover">
				<thead>
					<tr>
						<th scope="col">ID</th>
						<th scope="col">Nombre</th>
						<th scope="col">Precio</th>
						<th scope="col">Ver</th>
						<th scope="col">Editar</th>
						<th scope="col">Eliminar</th>
					</tr>
				</thead>

				<tbody>
					<?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<th scope="row">
								<?php echo e($plan->id); ?>

							</th>

							<th scope="row"><?php echo e($plan->plan_name); ?></th>
							<th scope="row">$<?php echo e($plan->plan_price); ?></th>
							<th scope="row">
								<a class="btn btn-outline-success" href="<?php echo e(route('plan.show',Crypt::encrypt($plan->id))); ?>"><i class="fas fa-eye"></i> Ver</a>
							</th>

							<th scope="row">
								<a class="btn btn-outline-primary" href="<?php echo e(route('plan.edit',Crypt::encrypt($plan->id))); ?>"><i class="far fa-edit"></i> Editar</a>
							</th>
							<th scope="row">
								<form action="<?php echo e(route('plan.destroy',Crypt::encrypt($plan->id))); ?>" method="POST">
									<?php echo csrf_field(); ?>
									<input type="hidden" name="_method" value="PATCH">
									<button class="btn btn-outline-danger" type="submit"><i class="fas fa-trash"></i> Eliminar</button>
								</form>
							</th>
						</tr>
					</tbody>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
			</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>