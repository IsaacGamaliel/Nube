<?php $__env->startSection('page', 'Videos'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-sm-12 table-responsive">
			<table class="table table-hover">
				<thead>
					<tr>
						<th scope="col"></th>
						<th scope="col">Nombre</th>
						<th scope="col">Subido</th>
						<th scope="col">Ver</th>
						<th scope="col">Eliminar</th>
					</tr>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<th scope="row">
								<?php if($video->extension == 'mp4' || $video->extension == 'MP4'): ?>
									<img class="img-responsive" src="<?php echo e(asset('img/files/mp4.svg')); ?>" width="50">
								<?php endif; ?>
								<?php if($video->extension == 'avi' || $video->extension == 'AVI'): ?>
									<img class="img-responsive" src="<?php echo e(asset('img/files/avi.svg')); ?>" width="50">
								<?php endif; ?>
								<?php if($video->extension == 'mpeg' || $video->extension == 'MPEG'): ?>
									<img class="img-responsive" src="<?php echo e(asset('img/files/mpeg.svg')); ?>" width="50">
								<?php endif; ?>
							</th>
							<th scope="row"><?php echo e($video->name); ?></th>
							<th scope="row"><?php echo e($video->created_at->DiffForHumans()); ?></th>
							<th scope="row">
								<a class="btn btn-primary" target="_blank" href="<?php echo e(asset('storage')); ?>/<?php echo e($folder); ?>/video/<?php echo e($video->name); ?>.<?php echo e($video->extension); ?>"><i class="fas fa-eye"></i> Ver</a>
							</th>
							<th scope="row">

								<a class="btn btn-danger text-white" data-toggle="modal" data-target="#deleteModal" data-file-id=<?php echo e($video->id); ?>><i class="fas fa-trash"></i> Eliminar</a> 
							</th>
						</tr>
					</tbody>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="container mb-5">
					      <div class="alert alert-warning" role="alert">
					         <span class="closebtn" onclick="this.parentElement.style.display='none';">x</span>
					         <strong>¡Atención!</strong> No tienes ningún video
					      </div>
					   </div>
					<?php endif; ?>
				</table>
			</div>
	</div>
</div>

<!-- Modal -->
	<?php echo $__env->make('admin.partials.modals.files', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo $__env->make('admin.partials.js.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>