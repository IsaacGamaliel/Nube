<?php $__env->startSection('page', 'Agregar archivo'); ?>

<?php $__env->startSection('content'); ?>
	
	<form action="<?php echo e(route('file.store')); ?>" method="POST" enctype="multipart/form-data">
		<?php echo csrf_field(); ?>

		<div class="row d-flex flex-row justify-content-center align-items-center pt-5">
			<div class="form-group">
				<label for="file">
					Selecciona un archivo para subirlo
				</label>

				<input type="file" class="form-control-file" name="file" required>
			</div>

			<div class="form-group">
				<button type="submit" class="btn btn-primary file">Subir archivo</button>
			</div>
		</div>
		
	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>