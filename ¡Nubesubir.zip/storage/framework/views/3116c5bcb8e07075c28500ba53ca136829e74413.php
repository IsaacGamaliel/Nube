<?php $__env->startSection('page', 'Detalles del usuario'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="row mb-3">
		<div class="col-sm-12">
			<div class="mt-5 pb-5">
                <?php if($user->image == "user.svg"): ?>
                <img src="<?php echo e(asset('img')); ?>/<?php echo e($user->image); ?>" width="120" class="img-responsive rounded-circle d-block mx-auto">
                <?php else: ?>
				<img src="<?php echo e(asset('Archivos')); ?>/<?php echo e($user->image); ?>" width="140" class="img-responsive rounded-circle d-block mx-auto">
                <?php endif; ?>
				<h4 class="text-center mt-3 mb-1"><?php echo e($user->name); ?></h4>
				<p class="text-center"><?php echo e($user->email); ?></p>

				<div class="d-flex row-flex justify-content-center">
					<a class="btn btn-outline-success" href="<?php echo e(route('user.edit', Crypt::encrypt($user->id))); ?>"><i class="fas fa-edit"></i> Editar perfil</a>
				</div>
			</div>
		</div>
	</div>

	<a class="btn btn-outline-success" href="<?php echo e(route('user.index')); ?>"><i class="fas fa-arrow-circle-left"></i> Volver</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>