<?php $__env->startSection('page', 'Detalles del rol'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<div class="form-row">
		<div class="col-sm-6 mb-3">
			<label for="RoleName">Nombre del rol</label>
			<input type="text" name="name" class="form-control is-valid" id="RoleName" value="<?php echo e($role->name); ?>" disabled>
		</div>
		<div class="col-sm-6 mb-3">
			<label class="ml-3">Permisos que tiene el rol</label>
				<div class="form-group">
					<ul class="nav navbar-nav list-inline">
						<div class="col-auto my-1 row">
							<?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
								<div class="col-sm-6">
									<li><i class="fas fa-unlock-alt"></i> <?php echo e($permission->description); ?></li>
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
								<li><i class="fas fa-lock"></i> El rol no tiene ningún permiso</li>
							<?php endif; ?>
						</div>
					</ul>
				</div>
		</div>
	</div>

	<a class="btn btn-outline-success" href="<?php echo e(route('role.index')); ?>"><i class="fas fa-arrow-circle-left"></i> Volver</a>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>