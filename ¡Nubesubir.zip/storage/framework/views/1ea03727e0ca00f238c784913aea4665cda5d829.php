<?php $__env->startSection('page', 'Editar datos del usuario'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<form class="was-validated" action="<?php echo e(route('user.update',Crypt::encrypt($user->id))); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<?php echo method_field('PATCH'); ?>

	<div class="form-row">
		<div class="col-sm-6 mb-3">
			<label for="UserName">Nombre del usuario</label>
			<input type="text" name="name" class="form-control is-valid" id="UserName" value="<?php echo e($user->name); ?>" required>
			<div class="invalid-feedback">¡No puedes dejar el usuario sin nombre!</div>
            <?php if($errors->has('name')): ?>
            <span class="invalid-feedback d-block" role="alert">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
            <?php endif; ?>
		</div>

		<div class="col-sm-6 mb-3">
			<label for="UserEmail">Email del usuario</label>
			<input type="text" name="email" class="form-control is-valid" id="UserEmail" value="<?php echo e($user->email); ?>" required>
			<div class="invalid-feedback">¡No puedes dejar el usuario sin email!</div>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback d-block" role="alert">
                <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
		</div>


		<div class="col-sm-6 mb-3">
			<label class="ml-3">Ten cuidado con los roles que otorgas</label>
				<div class="form-group">
					<ul>
						<div class="col-auto my-1">
							<div class="custom-control custom-checkbox mr-sm-2">
								<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<input type="checkbox" name="roles[]" class="custom-control-input" id="<?php echo e($role->id); ?>" value="<?php echo e($role->id); ?>"
											<?php if($user->roles->contains($role)): ?> checked
											<?php endif; ?>
										>
										<label class="custom-control-label" for="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</ul>
				</div>
		</div>
	</div>

	<button class="btn btn-primary" type="submit"><i class="fas fa-plus-circle"></i> Actualizar</button>
    <br>
    <br>
    <a class="btn btn-outline-success" href="<?php echo e(route('user.index')); ?>"><i class="fas fa-arrow-circle-left"></i> Volver</a>


</form>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>