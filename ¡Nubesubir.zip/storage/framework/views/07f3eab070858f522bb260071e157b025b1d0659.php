<?php $__env->startSection('page', 'Audios'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<?php $__empty_1 = true; $__currentLoopData = $audios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $audio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
			<div class="col-sm-12 col-md-4 pb-4">
				<audio src="<?php echo e(asset('storage')); ?>/<?php echo e($folder); ?>/audio/<?php echo e($audio->name); ?>.<?php echo e($audio->extension); ?>" controls>
				</audio>

				<a class="btn btn-danger pull-right mt-1 text-white" data-toggle="modal" data-target="#deleteModal" data-file-id=<?php echo e($audio->id); ?>><i class="fas fa-trash"></i> Eliminar</a> 
			</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
			<div class="container mb-3">
		      <div class="alert alert-warning" role="alert">
		         <span class="closebtn" onclick="this.parentElement.style.display='none';">x</span>
		         <strong>¡Atención!</strong> No tienes ningún archivo de audio
		      </div>
		   </div>
		<?php endif; ?>
	</div>
</div>

	<!-- Modal -->
	<?php echo $__env->make('admin.partials.modals.files', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  	<?php echo $__env->make('admin.partials.js.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>