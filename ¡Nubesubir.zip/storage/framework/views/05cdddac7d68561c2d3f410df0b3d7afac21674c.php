<?php $__env->startSection('page', 'Imágenes'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

      <div class="col-sm-6 col-md-4 mt-4">

        <div class="card" style="width: 18rem;">
          <img class="card-img-top" src="<?php echo e(asset('storage')); ?>/<?php echo e($folder); ?>/image/<?php echo e($image->name); ?>.<?php echo e($image->extension); ?>" alt="<?php echo e($image->name); ?>">
          <div class="card-body">
            <a href="<?php echo e(asset('storage')); ?>/<?php echo e($folder); ?>/image/<?php echo e($image->name); ?>.<?php echo e($image->extension); ?>" target="_blank" class="btn btn-primary"><i class="fas fa-eye"></i> Ver </a>

            <a class="btn btn-danger pull-right text-white" data-toggle="modal" data-target="#deleteModal" data-file-id=<?php echo e($image->id); ?>><i class="fas fa-trash"></i> Eliminar</a> 

          </div>
        </div>
        
      </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <div class="container mb-3">
          <div class="alert alert-warning" role="alert">
             <span class="closebtn" onclick="this.parentElement.style.display='none';">x</span>
             <strong>¡Atención!</strong> No se encontraron imágenes
          </div>
       </div>
    <?php endif; ?>
  </div>
</div>


  <!-- Modal -->
  <?php echo $__env->make('admin.partials.modals.files', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
  <?php echo $__env->make('admin.partials.js.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>