<?php $__env->startSection('page', 'Crear un nuevo rol'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<form class="was-validated" action="<?php echo e(route('user.store')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="_method" value="PATCH">

	<div class="form-row">
		<div class="col-sm-6 mb-3">
			<label for="UserName">Nombre</label>
			<input type="text" name="name" class="form-control is-valid" id="UserName" placeholder="Nombre del usuario" required>
			<div class="invalid-feedback">¡Debes agregar un nombre!</div>
            <?php if($errors->has('name')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
            <?php endif; ?>
		</div>

        <div class="col-sm-6 mb-3">
			<label for="username">Username</label>
			<input type="text" name="username" class="form-control is-valid" id="username" placeholder="nubeusuario" minlength="5" maxlength="20" required>
			<div class="invalid-feedback">¡Debes agregar un username!</div>
            <?php if($errors->has('username')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('username')); ?></strong>
            </span>
            <?php endif; ?>
		</div>


		<div class="col-sm-6 mb-3">
			<label for="UserEmail">Correo electrónico</label>
			<input type="email" name="email"  id="UserEmail" placeholder="nube@gmail.com" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
            name="email" value="<?php echo e(old('email')); ?>" maxlength="50" minlength="5"
            required>
			<div class="invalid-feedback">¡Debes agregar un correo electrónico!</div>
            <?php if($errors->has('email')): ?>
                <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('email')); ?></strong>
                </span>
            <?php endif; ?>
		</div>

		<div class="col-sm-6 mb-3">
			<label for="UserPassword">Contraseña</label>
			<input type="password" name="password"  id="UserPassword" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
            name="password" required maxlength="10" minlength="6">
			<div class="invalid-feedback">¡Debes agregar un Una contraseña!</div>
            <?php if($errors->has('password')): ?>
                <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('password')); ?></strong>
                </span>
            <?php endif; ?>
		</div>

		<div class="col-sm-6 mb-3">
			<label for="UserImage">Imagen (por defecto)</label>
			<input type="image" name="image" class="form-control" id="UserImage" value="user.svg" disabled>
		</div>
		<div class="col-sm-6 mb-3">
			<label class="ml-3">Ten cuidado con los permisos que otorgas</label>
				<div class="form-group">
					<ul>
						<div class="col-auto my-1">
							<div class="custom-control custom-checkbox mr-sm-2">
								<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<input type="checkbox" name="roles[]" class="custom-control-input" id="<?php echo e($role->id); ?>" value="<?php echo e($role->id); ?>">
										<label class="custom-control-label" for="<?php echo e($role->id); ?>"><?php echo e($role->name); ?></label>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</ul>
				</div>
		</div>
	</div>

	<button class="btn btn-primary" type="submit"><i class="fas fa-plus-circle"></i> Agregar</button>
    <br>
    <br>
    <a class="btn btn-outline-success" href="<?php echo e(route('user.index')); ?>"><i class="fas fa-arrow-circle-left"></i> Volver</a>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>