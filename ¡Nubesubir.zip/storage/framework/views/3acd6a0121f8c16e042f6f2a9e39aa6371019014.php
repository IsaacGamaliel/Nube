<?php $__env->startSection('page', 'Crear un nuevo rol'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('admin.partials.alert', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('admin.partials.error', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<form class="was-validated" action="<?php echo e(route('role.store')); ?>" method="POST">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="_method" value="PATCH">

	<div class="form-row">
		<div class="col-sm-6 mb-3">
			<label for="RoleName">Nombre del rol</label>
			<input type="text" name="name" class="form-control is-valid" id="RoleName" placeholder="Nombre del rol" class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
            name="name" value="<?php echo e(old('name')); ?>" maxlength="21"
            minlength="3" required>
			<div class="invalid-feedback">¡Debes agregar un nombre!</div>

            <?php if($errors->has('name')): ?>
            <span class="invalid-feedback" role="alert">
                <strong><?php echo e($errors->first('name')); ?></strong>
            </span>
            <?php endif; ?>

		</div>
		<div class="col-sm-6 mb-3">
			<label class="ml-3">Ten cuidado con los permisos que otorgas</label>
				<div class="form-group">
					<ul>
						<div class="col-auto my-1">
							<div class="custom-control custom-checkbox mr-sm-2">
								<?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<li>
										<input type="checkbox" name="permissions[]" class="custom-control-input" id="<?php echo e($permission->id); ?>" value="<?php echo e($permission->id); ?>">
										<label class="custom-control-label" for="<?php echo e($permission->id); ?>"><?php echo e($permission->description); ?></label>
									</li>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</div>
						</div>
					</ul>
				</div>
		</div>
	</div>

	<button class="btn btn-primary" type="submit"><i class="fas fa-plus-circle"></i> Agregar</button>
    <br>
    <br>
    <a class="btn btn-outline-success" href="<?php echo e(route('role.index')); ?>"><i class="fas fa-arrow-circle-left"></i> Volver</a>

</form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>