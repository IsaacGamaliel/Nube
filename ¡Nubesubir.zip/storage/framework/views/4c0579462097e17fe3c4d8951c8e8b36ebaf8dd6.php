<?php $__env->startSection('page', 'Documentos'); ?>

<?php $__env->startSection('content'); ?>

<div class="container">
	<div class="row">
		<div class="col-sm-12 table-responsive">
			<table class="table table-hover">
				<thead>
					<tr>
						<th scope="col"></th>
						<th scope="col">Nombre</th>
						<th scope="col">Subido</th>
						<?php if(Auth::user()->hasRole("Admin")): ?>
						<th scope="col">Usuario</th>
						<?php endif; ?>
						<th scope="col" width="27%">Ver</th>
						<th scope="col">Eliminar</th>
					</tr>
				</thead>
				<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $document): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<th scope="row">
								<?php if($document->extension == 'pdf' || $document->extension == 'PDF'): ?>
									<img class="img-responsive" src="<?php echo e(asset('img/files/pdf.svg')); ?>" width="50">
								<?php endif; ?>
								<?php if($document->extension == 'xlsx' || $document->extension == 'XLSX'): ?>
									<img class="img-responsive" src="<?php echo e(asset('img/files/excel.svg')); ?>" width="50">
								<?php endif; ?>
								<?php if($document->extension == 'docx' || $document->extension == 'DOCX'): ?>
									<img class="img-responsive" src="<?php echo e(asset('img/files/word.svg')); ?>" width="50">
								<?php endif; ?>
							</th>
							<th scope="row"><?php echo e($document->name); ?></th>
							<th scope="row"><?php echo e($document->created_at->DiffForHumans()); ?></th>
							<?php if(Auth::user()->hasRole("Admin")): ?>
							<th scope="col"><?php echo e($document->user->name); ?></th>
							<?php endif; ?>
							<th scope="row">
								<?php if($document->extension == 'pdf' || $document->extension == 'PDF'): ?>
									<a class="btn btn-primary" style="width: 55%;" target="_blank" href="<?php echo e(asset('storage')); ?>/<?php echo e($document->folder); ?>/document/<?php echo e($document->name); ?>.<?php echo e($document->extension); ?>"><i class="fas fa-eye"></i> Ver</a>
								<?php else: ?>
									<a class="btn btn-success" style="width: 55%;" target="_blank" href="<?php echo e(asset('storage')); ?>/<?php echo e($document->folder); ?>/document/<?php echo e($document->name); ?>.<?php echo e($document->extension); ?>"><i class="fas fa-download"></i> Descargar</a>
								<?php endif; ?>
								
							</th>
							<th scope="row">

								<a class="btn btn-danger text-white" data-toggle="modal" data-target="#deleteModal" data-file-id=<?php echo e($document->id); ?>><i class="fas fa-trash"></i> Eliminar</a> 
							
							</th>
						</tr>
					</tbody>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<div class="container mb-5">
					      <div class="alert alert-warning" role="alert">
					         <span class="closebtn" onclick="this.parentElement.style.display='none';">x</span>
					         <strong>¡Atención!</strong> No tienes ningún documento
					      </div>
					   </div>
					<?php endif; ?>
				</table>
			</div>
	</div>
</div>

<!-- Modal -->
	<?php echo $__env->make('admin.partials.modals.files', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
	<?php echo $__env->make('admin.partials.js.deleteModal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>