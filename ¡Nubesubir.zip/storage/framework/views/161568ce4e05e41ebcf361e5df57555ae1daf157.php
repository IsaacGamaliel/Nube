<?php $__env->startSection('content'); ?>
<main role="main">
    <section class="jumbotron text-center mb-0">
        <div class="row pt-5">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header"><?php echo e(__('Registro')); ?></div>

                            <div class="card-body">
                                <img src="<?php echo e(asset('img/auth/register.svg')); ?>" class="mb-5 mt-3" width="100">

                                <form method="POST" action="<?php echo e(route('register')); ?>" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>

                                    <div class="form-group row">
                                        <label for="name" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Nombre
                                            Completo')); ?></label>

                                        <div class="col-md-6">
                                            <input id="name" type="text"
                                                class="form-control<?php echo e($errors->has('name') ? ' is-invalid' : ''); ?>"
                                                name="name" value="<?php echo e(old('name')); ?>" maxlength="50" minlength="10"
                                                required autofocus>

                                            <?php if($errors->has('name')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('name')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="email" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Correo
                                            Electronico')); ?></label>

                                        <div class="col-md-6">
                                            <input id="email" type="email"
                                                class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>"
                                                name="email" value="<?php echo e(old('email')); ?>" maxlength="50" minlength="5"
                                                required>

                                            <?php if($errors->has('email')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('email')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="username" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Usuario')); ?></label>

                                        <div class="col-md-6">
                                            <input id="username" type="text"
                                                class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>"
                                                name="username" value="<?php echo e(old('username')); ?>" maxlength="20"
                                                minlength="5" required>

                                            <?php if($errors->has('username')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('username')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="image" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Imagen')); ?></label>

                                        <div class="col-md-6">
                                            <input id="image" type="file"
                                                class="form-control<?php echo e($errors->has('image') ? ' is-invalid' : ''); ?>"
                                                name="image" value="<?php echo e(old('image')); ?>" required>

                                            <?php if($errors->has('image')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('image')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="password" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Contraseña')); ?></label>

                                        <div class="col-md-6">
                                            <input id="password" type="password"
                                                class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>"
                                                name="password" required maxlength="10" minlength="6">

                                            <?php if($errors->has('password')): ?>
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($errors->first('password')); ?></strong>
                                            </span>
                                            <?php endif; ?>
                                        </div>
                                    </div>



                                    <div class="form-group row">
                                        <label for="password-confirm" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Confirma contraseña')); ?></label>

                                        <div class="col-md-6">
                                            <input id="password-confirm" type="password" class="form-control"
                                                name="password_confirmation" required maxlength="10" minlength="6">
                                        </div>
                                    </div>

                                    <div class="form-group row mb-0">
                                        <div class="col-md-6 offset-md-4">
                                            <button type="submit" class="btn btn-primary">
                                                <?php echo e(__('Registrarse')); ?>

                                            </button>
                                        </div>
                                    </div>

                                    <script>
                                        //Validaciones registro
                                        bootstrapValidate(['#name','#username','#email','#image','#password','#password-confirm'],'required:Campo vacio')
                                        bootstrapValidate('#name','min:5:Minimo 5|max:40:Maximo 40')
                                        bootstrapValidate('#email','email:Ingresa un correo valido|min:5:Minimo 5|max:40:Maximo 40')
                                        bootstrapValidate('#password-confirm','min:6:Minimo 6|max:10:Maximo 10|matches:#password:Contraseñas no son iguales')
                                    </script>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>